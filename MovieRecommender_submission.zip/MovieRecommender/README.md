# Movie recommender: biased MF versus NeuMF on MovieLens 100K

This folder contains the notebook for my Track B presentation. The notebook already holds the outputs of a full run, so it can be read without running it.

## Contents

| File | What it is |
|---|---|
| MovieRecommender.ipynb | The notebook. Every number and chart in the presentation comes from it |
| data/ml-100k | The MovieLens 100K files the notebook reads: ratings, users, films, genres and the five predefined folds (u1.base/u1.test up to u5.base/u5.test) |
| requirements.txt | The Python packages and the versions I used |

The data comes from GroupLens Research (https://grouplens.org/datasets/movielens/100k/) and is described in Harper and Konstan (2015).

## Running the notebook

Python 3.12 is recommended. Open a terminal in the folder that contains MovieRecommender.ipynb and the data folder, then:

Windows (PowerShell)

```
py -3.12 -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
jupyter notebook MovieRecommender.ipynb
```

macOS or Linux

```
python3.12 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
jupyter notebook MovieRecommender.ipynb
```

Then choose Run All.

The notebook reads the data with the relative path data/ml-100k, so open it from the folder that contains MovieRecommender.ipynb and the data folder.

## If scikit-surprise does not install

On Windows, pip needs the Microsoft C++ Build Tools for scikit-surprise. Without them, install it with conda and the rest with pip:

```
conda install -c conda-forge scikit-surprise
pip install -r requirements.txt
```
